# voice-prescription
One of the problem statement given by SIH.











Steps to run this project.










1.Installation-





















              1.Install the library tkinter for windows use command - pip install tk .
							For linux use command- apt-get install python-tk.
							2.Install another library speech_recognition for windows use 
							command - pip install SpeechRecognition  .
							3.pip install gTTS  .
							4.pip install secure-smtplib  .
							5.pip install pandas.
							6.pip install xlsxwriter.
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
2.For giving voice input earphones are necessary.Without earphones input is cann't be given to the program.









3.For sending email some changes in the code are necessary to do.
 at line-124 in code
 
 		sender_email = "Please enter your name here"
    
    password = "Please enter your password of email"






















4. If gmail is blocking your email due to security purpose then you will get error.
	 to solve this error go to your google account security->Activate 2 step verification->
	 create app passwoed->user that app password in your code.












Input to program


















1.First it will ask for patient name.
2. Then it will ask for patient age and gender.
3.Next it will ask doctor for suggetions.
4.Then medicine name.
5.At last it will ask for time of medicine
6.Receipt will be generated.
7.You have to fill patient email address into it.
8.click send email button .Email will be send to patient.
